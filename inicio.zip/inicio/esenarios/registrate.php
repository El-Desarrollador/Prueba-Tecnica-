<?php 
    include_once "./partials/head.php";
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
?>
<!DOCTYPE html>
<html lang="es">

<head><meta charset="euc-jp">
    <title>Registrate</title>
</head>

<body>

    <div class="d-flex justify-content-center align-items-center flex-column">

        <?php 
            session_start();

            if (isset($_SESSION['notifications_auth'])) {
         ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['notifications_auth']?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php
                unset($_SESSION['notifications_auth']);
            }
        ?>
        <div class="card">
            <div class="card-header">
                <h3>Registrate</h3>
            </div>
            <div class="card-body">
                <form action="./app/registrate.php" method="post">
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3 row">
                                <label for="staticEmail" class="col-auto col-form-label">Tipo de identificacion</label>
                                <div class="col-sm-7">
                                    <select class="form-select" aria-label="Tipo de identificacion"
                                        name="tipo_identificacion" required>
                                        <?php
                                            require_once "./db/conexion.php";
                                            $sql = "SELECT * FROM tipos_identificacion";
                                            $result = mysqli_query($con,$sql);
                                            while ($data = mysqli_fetch_assoc($result)) {
                                                ?>
                                        <option value="<?php echo $data['id']?>">
                                            <?php echo $data['abreviacion']." - ".$data['nombre_completo']?></option>
                                        <?php
                                            }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3 row">
                                <label for="staticEmail" class="col-auto col-form-label">Numero de
                                    identificacion</label>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control" placeholder="Digite el numero de identificacion" name="num_identificacion" required maxlength="50" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3 row">
                                <label for="" class="col-auto col-form-label">Nombre de usuario</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" max="" placeholder="Digite su nombre de usuario" name="nombre_de_usuario" required maxlength="40" />
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3 row">
                                <label for="" class="col-auto col-form-label">Password</label>
                                <div class="col-sm-9">
                                    <input type="password" class="form-control" name="password" placeholder="Digite su password" maxlength="50" required />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3 row">
                                <label for="" class="col-auto col-form-label">Nombre</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" max="" name="nombre" placeholder="Digite su nombre" maxlength="50" required />
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3 row">
                                <label for="" class="col-auto col-form-label">Apellido</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" maxlength="50" placeholder="Digite su apellido" maxlength="50" name="apellido" required />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-7">
                            <div class="mb-3 row">
                                <label for="" class="col-auto col-form-label">E-mail</label>
                                <div class="col-sm-10">
                                    <input type="email" class="form-control" max="" name="email" placeholder="Digite su e-mail" maxlength="70" required />
                                </div>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="mb-3 row">
                                <label for="" class="col-auto col-form-label">Telefono</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="telefono" placeholder="Digite su telefono" maxlength="50" required />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary ">Registrate</button>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                Si ya tienes una cuenta <a href="./index.php">Inicia sesion</a>
            </div>
        </div>
    </div>
    <?php include_once "./partials/foot.php"?>
</body>

</html>