<?php
    $host = "localhost";
    $username = "root";
    $pasword = "";
    $dbname = "sistemapagos";

    $con = mysqli_connect($host,$username,$pasword,$dbname);


?>