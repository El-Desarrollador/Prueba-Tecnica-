<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');
session_start();  
if ($_SESSION['logued'] == true) {
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include_once "./partials/head.php";?>
    <title>Pago - <?php echo $_SESSION['nombre']." ".$_SESSION['apellido']?></title>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand"
                href="./user_pay_admin.php"><?php echo $_SESSION['nombre']." ".$_SESSION['apellido']?> -
                <?php echo $_SESSION['rol']['nombre']?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                </ul>
                <div class="d-flex">
                    <a href="../dashboard/index.php" class="btn btn-primary">Dashoard</a>
                </div>
                <div class="d-flex">
                    <a href="./app/logout.php" class="btn btn-primary">Salir</a>
                </div>
            </div>
        </div>
    </nav>
    <div class="container-fluid d-flex justify-content-center align-items-center">
        <div class="card mt-3 mb-3 w-75">
            <div class="card-header">
                <div class="row">
                    <div class="col-8">
                        <h4>Carreras Precenciales</h4>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th scope="col">Nombre</th>
                                <th scope="col">Valor Carrera</th>
                                <th scope="col">Accion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                require_once "./db/conexion.php";
                                $sql = "SELECT * FROM productos";
                                $result = mysqli_query($con,$sql);
                                while ($data = mysqli_fetch_assoc($result)) {
                            ?>
                            <tr>
                                <td><?php echo $data['nombre']?></td>
                                <td>$<?php echo $data['valor_con_iva']?></td>
                                <td>
                                    <a href="./user_pay_admin.php?id_producto=<?php echo $data['id']?>&valor_producto=<?php echo $data['valor_con_iva']?>"
                                        class="btn btn-primary">Comprar</a>
                                </td>
                            </tr>
                            <?php
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php include_once "./partials/foot.php";
    if (isset($_GET['valor_producto']) && isset($_GET['id_producto'])) {
        $id_cliente = $_SESSION['id_user'];
        $id_producto = $_GET['id_producto'];
        $sql = "INSERT INTO pagos (id_producto,id_cliente) VALUES($id_producto,$id_cliente)";
        $result = mysqli_query($con,$sql);
    ?>
    <script>
     
    }).then(response => console.log(response))
    </script>
</body>

</html>
<?php
    }

    }else{
        header("Location: index.php");
    }

?>