<?php
    require_once "./db/conexion.php";
	$id=$_POST['id'];
	$nombre=$_POST['nombre'];
	$descripcion=$_POST['descripcion'];
	$valor_con_iva=$_POST['valor_con_iva'];
	$consulta=mysqli_query($con,"UPDATE productos SET nombre='$nombre', descripcion='$descripcion', valor_con_iva='$valor_con_iva' WHERE id='$id'");
	header('location: productos.php');
?>