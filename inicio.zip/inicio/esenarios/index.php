<?php 
    include_once "./partials/head.php";
        
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
?>
<!DOCTYPE html>
<html lang="es">

<head><meta charset="euc-jp">
    
    <title>Iniciar sesion</title>
</head>

<body>
    <div class="d-flex justify-content-center align-items-center flex-column">
        <?php 
            session_start();
            if (isset($_SESSION['notifications_auth'])) {
        ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['notifications_auth']?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php
                unset($_SESSION['notifications_auth']);
            }
        ?>
        <div class="card">
            <div class="card-header">
                <h3>Iniciar sesion</h3>
            </div>
            <div class="card-body">
                <form action="./app/login.php" method="post">

                    <div class="form-group m-2">
                        <div class="mb-3 row">
                            <label for="" class="col-auto col-form-label">Nombre de usuario</label>
                            <input type="text" class="form-control" max="" placeholder="Digite su nombre de usuario"
                                name="nombre_de_usuario" maxlength="40" required>
                        </div>
                    </div>
                    <div class="form-group m-2">
                        <div class="mb-3 row">
                            <label for="" class="col-auto col-form-label">Password</label>
                            <input type="password" class="form-control" name="password"
                                placeholder="Digite su password" maxlength="50" required>
                        </div>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary ">Iniciar sesion</button>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                Si no tienes una cuenta <a href="./registrate.php">Registrate</a>
            </div>
        </div>
    </div>
    <?php include_once "./partials/foot.php"?>
</body>

</html>