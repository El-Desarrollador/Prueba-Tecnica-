<?php
    session_start();
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    $_SESSION['logued'] = false;
    session_unset();
    session_destroy();
    header("Location: ../index.php");
?>