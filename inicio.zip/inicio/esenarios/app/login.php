<?php
    require_once "../db/conexion.php";
    session_start();
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    $nombre_de_usuario = $_POST['nombre_de_usuario'];
    $password = md5($_POST['password']);

    $sql = "SELECT * FROM usuarios WHERE nombre_de_usuario = '$nombre_de_usuario' AND password = '$password'";
    $result = mysqli_query($con,$sql);
    $num_rows = mysqli_num_rows($result);

    if ($num_rows > 0) {
        $user_data = mysqli_fetch_assoc($result);
        $id_rol = $user_data['id_rol'];
        $sql = "SELECT * FROM roles WHERE id = $id_rol";
        $result = mysqli_query($con,$sql);
        $rol = mysqli_fetch_assoc($result); 
        $_SESSION['logued'] = true;
        $_SESSION['email'] = $user_data['email'];
        $_SESSION['id_user'] = $user_data['id'];
        $_SESSION['nombre'] = $user_data['nombre'];
        $_SESSION['apellido'] = $user_data['apellido'];
        $_SESSION['tipo_identificacion'] = $user_data['tipo_identificacion'];
        $_SESSION['telefono'] = $user_data['telefono'];
        $_SESSION['id_rol'] = $user_data['id_rol'];
        $_SESSION['rol'] = $rol;
        if ($user_data['id_rol'] == 1) {
            header("Location: ../admin.php");
        }else {
            header("Location: ../user_pay_admin.php");
        }
    }else{
        $_SESSION['notifications_auth'] = "Error al iniciar sesion. Revise los datos ingresados e intentelo de nuevo";
        header("Location: ../index.php");
    }

?>