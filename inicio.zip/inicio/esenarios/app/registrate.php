<?php
    require_once "../db/conexion.php";
    session_start();

    error_reporting(E_ALL);
    ini_set('display_errors', '1');

    $nombre_de_usuario = $_POST['nombre_de_usuario'];
    $password = md5($_POST['password']);
    $id_rol = 2;
    $tipo_identificacion = $_POST['tipo_identificacion'];
    $num_identificacion = $_POST['num_identificacion'];
    $email = $_POST['email'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $telefono = $_POST['telefono'];

    $sql = "INSERT INTO usuarios (`nombre_de_usuario`, `password`, `id_rol`, `tipo_identificacion`, `num_identificacion`, `email`, `nombre`, `apellido`, `telefono`) VALUES('$nombre_de_usuario', '$password', '$id_rol', '$tipo_identificacion', '$num_identificacion', '$email', '$nombre', '$apellido', '$telefono')";

    $result = mysqli_query($con,$sql);

    if ($result) {
        $_SESSION['notifications_auth'] = "Registrado correctamente. Logueate...";
        header("Location: ../index.php");
    }else{
        $_SESSION['notifications_auth'] = "Error al registrarse. Revise los datos ingresados e intentelo de nuevo";
        header("Location: ../registrate.php");
    }

?>