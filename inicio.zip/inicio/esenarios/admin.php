<?php
    require_once "./db/conexion.php";
    session_start();
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
<?php
$id_categoria=$_GET['id'];
require_once "./db/conexion.php";
$buscar=mysqli_query($conexion,"SELECT * FROM productos WHERE id='$id'");
$fila=mysqli_fetch_array($buscar);
$nombre=$fila['nombre'];
$descripcion=$fila['descripcion'];
$valor_con_iva=$fila['valor_con_iva'];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Editar productos</h1>
<form action="modificar_producto.php" method="post">
	<label>Nombre producto: </label>
	<input type="hidden" name="id" value="<?php echo $id;?>">
	<input type="text" name="nombre" value="<?php echo $nombre;?>"><br>
	<input type="text" name="descripcion" value="<?php echo $descripcion;?>"><br>
	<input type="text" name="valor_con_iva" value="<?php echo $valor_con_iva;?>"><br>
	<br>
	<input type="submit" value="Guardar">
</form>
</body>
</html>