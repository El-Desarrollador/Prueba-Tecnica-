<?php require_once "./vistas/parte_superior.php"?>

<!-- INICIO del contenido principal -->
<div class="contaner">
    <h1>CRUD WityPiece</h1>
</div>

<!-- FIN del contenido principal -->


<?php require_once "./vistas/parte_inferior.php"?>